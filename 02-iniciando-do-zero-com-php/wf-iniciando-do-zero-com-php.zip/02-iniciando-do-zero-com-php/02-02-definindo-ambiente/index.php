<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.02 - Definindo ambiente");

/*
 * Documentando o exemplo
 */
fullStackPHPClassSession("Debug Section", __LINE__);

var_dump($_SERVER);