<form name="post" action="./?post=true" method="post" enctype="multipart/form-data">
    <p style="margin-bottom: 10px; text-align: right"><a href="./" title="Atualizar">Atualizar</a></p>
    <input type="file" name="file"/>
    <button>Enviar Agora!</button>
</form>